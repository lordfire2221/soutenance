// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase : {
    apiKey: "AIzaSyALXYQwePXvMVLAQVXtQ0kKOrjrDzk_SuA",
    authDomain: "pacifique-86242.firebaseapp.com",
    projectId: "pacifique-86242",
    storageBucket: "pacifique-86242.appspot.com",
    messagingSenderId: "873654897606",
    appId: "1:873654897606:web:9cc52b11c085a1124000c7",
    measurementId: "G-EK9PFCDTBV"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FirebaseService } from '../services/firebase.service';

@Component({
  selector: 'app-apprenants',
  templateUrl: './apprenants.component.html',
  styleUrls: ['./apprenants.component.scss']
})
export class ApprenantsComponent implements OnInit {
  sidebarVisible = true;
  public datas: any[] = [];
  isShow = false;
  role:String = "";

  constructor(private userService: AuthService, public afAuth: AngularFireAuth,
    private router: Router, private firebaseService: FirebaseService) { }

  ngOnInit(): void {
    this.firebaseService.getApprenantsT(50).subscribe(
      (res:any) => (this.datas = res,this.isShow  = true)
    )
    this.role = JSON.parse(this.userService.getData("user")!)[0].role
  }
  delete(id:string){
    if(confirm("Voullez-vous supprimer cet élément ?"))
      this.firebaseService.delete(id)
  }
  modify(id:string){
    this.userService.setDataInLocalStorage('id',id)
    this.router.navigate([`apprenants/modifier`])
  }
  async logout() {
    this.userService.clearStorage();
    await this.afAuth.signOut();
    localStorage.removeItem('token');
    this.router.navigate(['login']);
  }

}

import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { FirebaseService } from 'src/app/services/firebase.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { HttpClient } from '@angular/common/http';
import * as bcrypt from 'bcryptjs';


@Component({
  selector: 'app-ajouter-admin',
  templateUrl: './ajouter-admin.component.html',
  styleUrls: ['./ajouter-admin.component.scss']
})
export class AjouterAdminComponent implements OnInit {
  sidebarVisible = true;
  public ajouterAdmin!: UntypedFormGroup;
  public datas!: any;
  selectedFiles: FileList | undefined;
  percentage!: number;
  communes: string[] = [
    "Banikoara",
    "Kandi",
    "Gogonou",
    "Karimama",
    "Malanville",
    "Ségbana",
    "Boukoumbé",
    "Cobli",
    "Kérou",
    "Kouandé",
    "Matéri",
    "Natitingou", "Péhunco",
    "Tanguiéta",
    "Toukountouna", " Abomey - Calavi",
    "Allada",
    "Kpomassè",
    "Ouidah",
    "Sô-Ava",
    "Toffo",
    "Tori",
    "Zê",
    "Bembèrèkè",
    "Kalalé",
    "N’Dali",
    "Nikki",
    "Parakou",
    "Pèrèrè",
    "Sinendé",
    "Tchaourou",
    "Bantè",
    "Dassa-Zoumè",
    "Glazoué",
    "Ouessè",
    "Savalou",
    "Savè",
    "Aplahoué",
    "Djakotomey",
    "Dogbo",
    "Klouékanmey",
    "Lalo",
    "Toviklin",
    "Bassila",
    "Copargo",
    "Djougou",
    "Ouaké",
    "Cotonou",
    "Athiémé",
    "Bopa",
    "Comè",
    "Grand-Popo",
    "Houéyogbé",
    "Lokossa",
    "Adjarra",
    "Adjohoun",
    "Aguégués",
    "Akpro-Missérété",
    "Avrankou",
    "Bonou",
    "Dangbo",
    "Porto-Novo",
    "Sèmè-Podji",
    "Adja-ouèrè",
    "Ifangni",
    "Kétou",
    "Pobè",
    "Sakété",
    "Abomey",
    "Agbangnizoun",
    "Bohicon",
    "Covè",
    "Djidja",
    "Ouinhi",
    "Zagnanado",
    "Za-kpota",
    "Zogbodomè",
  ]

  constructor(
    private firebaseService: FirebaseService,
    private fb: UntypedFormBuilder,
    private router: Router,
    private userService: AuthService,
    public afAuth: AngularFireAuth,
    private http: HttpClient
  ) {
    this.ajouterAdmin = this.fb.group({
      nom: ['', [Validators.required, Validators.maxLength(255)]],
      dateNaissance: ['', Validators.required],
      role: ['', Validators.required],
      lieuNaissance: ['', Validators.required],
      phone: ['', Validators.required],
      lieuResidence: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      statut: [false, Validators.required],
      genre: ['', Validators.required]
    })
  }

  logout() {
    this.userService.clearStorage();
    this.router.navigate(['/login'])
  }
  onSubmit() {
    const password = this.ajouterAdmin.value.phone
    this.firebaseService.testAdmin(this.ajouterAdmin.value.email).subscribe(
      (res: any) => {
        if (res.size == 0) {
          this.afAuth
            .createUserWithEmailAndPassword(this.ajouterAdmin.value.email, password).then((res: any) => {
              this.firebaseService.createUsers({ ...this.ajouterAdmin.value })
              this.router.navigate(['admin'])
            }).catch((error) => {
              if (error.message.indexOf("auth/email-already-in-use") !== -1 ) {
                if (confirm("Voulez vous utiliser les mêmes identifiants que celui du compte apprenant ?")) {
                  this.firebaseService.createUsers({ ...this.ajouterAdmin.value })
                  this.router.navigate(['admin'])
                }
              }else
                window.alert(error.message);
            });
        } else {
          alert("OOOPS! Un utilisateur utilise déjà cette adresse mail")
          this.ajouterAdmin.get("email")?.reset
        }
      }
    )
  }
  ngOnInit(): void {
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FirebaseService } from '../services/firebase.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  sidebarVisible = true;
  public datas: any[] = [];
    isShow = false


  constructor(private userService: AuthService, public afAuth: AngularFireAuth,
    private router: Router, private firebaseService: FirebaseService) { }

  ngOnInit(): void {
    this.firebaseService.getAdminT(50).subscribe(
      (res:any) => (this.datas = res,this.isShow  = true)
    )
  }
  delete(id:string){
    if(confirm("Voulez-vous supprimer cet élément?"))
      this.firebaseService.deleteAdmin(id)
  }
  desactivate(id:string){
    this.firebaseService.desactivateAdmin(id)
  }
  activate(id: string) {
    this.firebaseService.validateAdmin(id);
  }
  modify(id:string){
    this.userService.setDataInLocalStorage('id',id)
    this.router.navigate([`admin/modifier`])
  }
  logout() {
    this.userService.clearStorage();
    return this.afAuth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['login']);
    });
  }

}

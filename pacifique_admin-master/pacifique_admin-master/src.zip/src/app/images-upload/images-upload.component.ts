import { Component } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FirebaseService } from '../services/firebase.service';

@Component({
  selector: 'app-images-upload',
  templateUrl: './images-upload.component.html',
  styleUrls: ['./images-upload.component.scss']
})
export class ImagesUploadComponent {
  sidebarVisible = true;
  imageForm:FormGroup
  constructor(private storage: AngularFireStorage, private db: AngularFirestore,private userService: AuthService,private firebaseService: FirebaseService, public afAuth: AngularFireAuth,
    private router: Router,private fb:FormBuilder ) {
      this.imageForm = fb.group({
        type:['',Validators.required]
      })
    }
    upload(event:any) {
      const files = event.target.files;
      for (const file of files) {
        const filePath = `images/${file.name}`;
        const fileRef = this.storage.ref(filePath);
        const task = fileRef.put(file);
        task.snapshotChanges().subscribe((snapshot:any) => {
          if (snapshot.bytesTransferred === snapshot.totalBytes) {
            fileRef.getDownloadURL().subscribe(url => {
              this.firebaseService.createImage({link:url,type:this.imageForm.value.type})
            });
          }
        })
        alert("done");
      }
    }
  logout() {
    this.userService.clearStorage();
    return this.afAuth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['login']);
    });
  }
}

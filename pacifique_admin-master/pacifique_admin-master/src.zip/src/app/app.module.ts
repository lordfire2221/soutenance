import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFirestoreModule } from '@angular/fire/compat/firestore';
import { environment } from '../environments/environment';
import { AngularFireAuthModule } from '@angular/fire/compat/auth';
import { AngularFireStorageModule } from '@angular/fire/compat/storage';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GestionComponent } from './gestion/gestion.component';
import { ApprenantsComponent } from './apprenants/apprenants.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { ModifierComponent } from './apprenants/modifier/modifier.component';
import { AjouterComponent } from './apprenants/ajouter/ajouter.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MessagesComponent } from './messages/messages.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { FourOhFourComponent } from './four-oh-four/four-oh-four.component';
import { FormComponent } from './form/form.component';
import { HttpClientModule } from '@angular/common/http';
import { DesactiverComponent } from './desactiver/desactiver.component';
import { NotesComponent } from './notes/notes.component';
import { ProgrammeComponent } from './programme/programme.component';
import { ConduiteComponent } from './conduite/conduite.component';
import { CodeComponent } from './code/code.component';
import { ProgrammeCodeComponent } from './code/programme-code/programme-code.component';
import { ProgrammeConduiteComponent } from './conduite/programme-conduite/programme-conduite.component';
import { CoursComponent } from './cours/cours.component';
import { ExercicesComponent } from './exercices/exercices.component';
import { AjoutExoComponent } from './exercices/ajout-exo/ajout-exo.component';
import { ModifierExoComponent } from './exercices/modifier-exo/modifier-exo.component';
import { ModifierCoursComponent } from './cours/modifier-cours/modifier-cours.component';
import { ImagesUploadComponent } from './images-upload/images-upload.component';
import { CrenneauComponent } from './crenneau/crenneau.component';
import { ProgrammeCrenneauComponent } from './crenneau/programme-crenneau/programme-crenneau.component';
import { DesactiverAdminComponent } from './admin/desactiver-admin/desactiver-admin.component';
import { ModifierAdminComponent } from './admin/modifier-admin/modifier-admin.component';
import { AjouterAdminComponent } from './admin/ajouter-admin/ajouter-admin.component';
import { AdminComponent } from './admin/admin.component';
import { PresencesComponent } from './presences/presences.component';
import { ValidationsComponent } from './presences/validations/validations.component';


@NgModule({
  declarations: [
    AppComponent,
    GestionComponent,
    ApprenantsComponent,
    NavbarComponent,
    SidebarComponent,
    FooterComponent,
    ModifierComponent,
    AjouterComponent,
    MessagesComponent,
    SignupComponent,
    LoginComponent,
    FourOhFourComponent,
    FormComponent,
    DesactiverComponent,
    NotesComponent,
    ProgrammeComponent,
    ConduiteComponent,
    CodeComponent,
    ProgrammeCodeComponent,
    ProgrammeConduiteComponent,
    CoursComponent,
    ExercicesComponent,
    AjoutExoComponent,
    ModifierExoComponent,
    ModifierCoursComponent,
    ImagesUploadComponent,
    CrenneauComponent,
    ProgrammeCrenneauComponent,
    DesactiverAdminComponent,
    ModifierAdminComponent,
    AjouterAdminComponent,
    AdminComponent,
    PresencesComponent,
    ValidationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFireModule.initializeApp(environment.firebase),
 	  AngularFirestoreModule,
    AngularFireAuthModule,
    AngularFireStorageModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

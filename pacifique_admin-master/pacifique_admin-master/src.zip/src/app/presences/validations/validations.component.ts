import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FirebaseService } from '../../services/firebase.service';

@Component({
  selector: 'app-validations',
  templateUrl: './validations.component.html',
  styleUrls: ['./validations.component.scss']
})
export class ValidationsComponent implements OnInit {
  sidebarVisible = true;
  public datas: any[] = [];
  isShow = false;
  role:String = "";
  user:any={url:"",nom:""};
  id:string=""


  constructor(private userService: AuthService, public afAuth: AngularFireAuth,
    private router: Router, private firebaseService: FirebaseService) { }

  ngOnInit(): void {
    this.firebaseService.getPresencesPending().subscribe(
      (res:any) => (this.datas = res,this.isShow  = true)
    )
  }
  valider(id:string){
    if(confirm("Voullez-vous valider cette présence ?"))
      this.firebaseService.activatePresence(id)
  }
  get(id:string,uid:string){
    this.id=id;
    this.firebaseService.getApprenantDatas(uid).subscribe((res:any)=>{
      this.user = res[0]
    })
  }
  logout() {
    this.userService.clearStorage();
    return this.afAuth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['login']);
    });
  }

}

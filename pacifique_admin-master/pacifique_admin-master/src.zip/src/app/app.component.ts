import { Component, OnInit } from '@angular/core';
import { FirebaseService } from './services/firebase.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'permis-ecole-admin';
  constructor(private firebaseservice:FirebaseService){

  }
  ngOnInit(): void {
    var date = new Date()
    var day = date.getDay()
    if(day < 3){
      this.firebaseservice.getDisponibiliteT('conduite').subscribe(
        (res: any) => {
          var datas = res;
          datas.forEach((element:any) => {
            this.firebaseservice.activate(element.id)
          });
        }
      )
      this.firebaseservice.getDisponibiliteT('crenneau').subscribe(
        (res: any) => {
          var datas = res;
          datas.forEach((element:any) => {
            this.firebaseservice.activate(element.id)
          });
        }
      )
    }
  }
}

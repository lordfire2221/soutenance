import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgrammeCodeComponent } from './programme-code.component';

describe('ProgrammeCodeComponent', () => {
  let component: ProgrammeCodeComponent;
  let fixture: ComponentFixture<ProgrammeCodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProgrammeCodeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProgrammeCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { FirebaseService } from 'src/app/services/firebase.service';
import * as moment from 'moment'

@Component({
  selector: 'app-programme-code',
  templateUrl: './programme-code.component.html',
  styleUrls: ['./programme-code.component.scss']
})
export class ProgrammeCodeComponent implements OnInit {
  sidebarVisible = true;
  public datas:any[]=[];
  public programme:any = {uid:'',jour:0,heure:'',type:'code',semaine:''}
  public programmes:any[] = []
  public isShow:boolean = false;
  constructor(private userService: AuthService, public afAuth: AngularFireAuth,
    private router: Router, private firebaseService: FirebaseService) { }
  ngOnInit(): void {
    this.firebaseService.getDisponibilite('code').subscribe(
      (res:any)=>{
        this.datas = res;
        this.isShow = true
      }
    )
  }
  nextMonday(){
    let today = moment();
    let daysUntilMonday = 7-today.weekday();
    if (daysUntilMonday === 7){
      daysUntilMonday = 0
    }
    let nextMonday = today.add(daysUntilMonday, 'days')
    return nextMonday
  }
  select(day:number,hour:string,uid:string,event:any){
    this.programme.uid=uid;
    this.programme.jour = day;
    this.programme.heure = hour;
    this.programme.semaine = this.nextMonday();
    if (event.target.checked)
      this.addItem(this.programme)
    else
      this.removeItem(this.programme)
  }
  decompose(string:string,pos:number){
    return string.split('"')[pos]
  }
  logout() {
    this.userService.clearStorage();
    return this.afAuth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['login']);
    });
  }
  
  addItem(item: any) {
    this.programmes.push(item);
  }
  removeItem(item: any) {
    this.programmes = this.programmes.filter(i => i !== item);
  }
  validate(){
    if(confirm('Voulez-vous enregistrer les modification ?')){
      this.firebaseService.createProgramme(this.programmes)
    }else{
      console.log('azerty')
    }
  }
}

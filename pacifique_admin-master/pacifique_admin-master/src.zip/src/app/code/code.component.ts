import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { FirebaseService } from 'src/app/services/firebase.service';

@Component({
  selector: 'app-code',
  templateUrl: './code.component.html',
  styleUrls: ['./code.component.scss']
})
export class CodeComponent implements OnInit {
  sidebarVisible = true;
  public datas: any[] = [];
  public isShow: boolean = false;
  public name: string = "";
  public heures: any = [];
  public jours: any = ["Lundi","Mercredi","Vendredi"];
  public modifierProgramme: UntypedFormGroup = this.fb.group(
    {
      heure: ['', [Validators.required, Validators.maxLength(255)]],
        jour: ['', [Validators.required, Validators.maxLength(255)]],
        type: ['', [Validators.required, Validators.maxLength(255)]],
        uid: ['', [Validators.required, Validators.maxLength(255)]],
        id: ['', [Validators.required, Validators.maxLength(255)]]
    }
  );
  constructor(private userService: AuthService, public afAuth: AngularFireAuth,
    private router: Router, private firebaseService: FirebaseService,private fb: UntypedFormBuilder) { }
  ngOnInit(): void {
    this.firebaseService.getProgramme('code').subscribe(
      (res: any) => {
        this.datas = res;
        this.isShow = true
      }
    )
  }
  decompose(string: string, pos: number) {
    return string.split('"')[pos]
  }
  getDispo(uid:string,jour:number){
    
    this.firebaseService.getDisponibiliteSingle(uid,"code").subscribe(
      (res:any)=>{
        console.log(res)
        this.userService.setDataInLocalStorage('disponibilite',JSON.stringify(res[0]))
      }
    )
    var dispo = JSON.parse(this.userService.getData('disponibilite')!).disponibilite
    this.heures = dispo[jour].split('"')
    this.heures.splice(0,1)
    this.heures.splice(1,1)
    this.heures.splice(2,1)
  }
  select(uid:string,id:string){
    this.firebaseService.getProgrammeSingle(id).subscribe(
      (res:any)=>{
        this.userService.setDataInLocalStorage('programme',JSON.stringify(res))
      }
    )
    var prgm = JSON.parse(this.userService.getData('programme')!)
    this.modifierProgramme = this.fb.group(
      {
        heure: [prgm.heure, [Validators.required, Validators.maxLength(255)]],
        jour: [prgm.jour, [Validators.required, Validators.maxLength(255)]],
        type: [prgm.type, [Validators.required, Validators.maxLength(255)]],
        uid: [prgm.uid, [Validators.required, Validators.maxLength(255)]],
        id: [prgm.id, [Validators.required, Validators.maxLength(255)]]
      }
    )
    this.firebaseService.getApprenantDatas(uid).subscribe(
      (res: any) => {
        this.name = res[0].nom;
      }
    )
  }
  onSubmit(){
    var formvalue = this.modifierProgramme.value
    this.firebaseService.modifyPrgm(formvalue,formvalue.id)
  }
  logout() {
    this.userService.clearStorage();
    return this.afAuth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['login']);
    });
  }
}

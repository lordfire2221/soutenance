import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FileUploadService } from '../services/file-upload.service';
import { FirebaseService } from '../services/firebase.service';
import * as bcrypt from 'bcryptjs';



@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  sidebarVisible = true;

  public registerForm: FormGroup;
  public errorMessage!: string;
  public isLogin: boolean = false;
  selectedFiles: FileList | undefined;
  percentage!: number;

  constructor(private fb: FormBuilder,
    private router: Router,
    public afAuth: AngularFireAuth,
    public firebaseService: FirebaseService,
    private uploadService: FileUploadService
  ) {
    this.registerForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(4)]],
      password_conf: ['', [Validators.required, Validators.minLength(4)]]
    })
  }

  onSubmit() {
    const formValue = this.registerForm.value;
    if (formValue.password === formValue.password_conf) {
      this.firebaseService.createUsers({
        email: formValue.email,
        password: bcrypt.hashSync(formValue.password, 10)
      });
      this.router.navigate(['login'])
    }
    else {
      alert('Les mots de passe ne corespondent pas!')
    }
  }

  ngOnInit(): void {
  }

}

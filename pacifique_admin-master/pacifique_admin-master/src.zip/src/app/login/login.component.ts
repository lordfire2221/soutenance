import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { getAuth } from 'firebase/auth';
import * as bcrypt from 'bcryptjs';
import { FirebaseService } from '../services/firebase.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  sidebarVisible = true;

  public loginForm: FormGroup;
  public errorMessage!: string;
  public isLogin: boolean = false;
  constructor(private fb: FormBuilder,
    private userService: AuthService,
    private firebaseService: FirebaseService,
    private router: Router,
    private _api: ApiService,
    public afAuth: AngularFireAuth
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(4)]]
    })
  }

  onSubmit() {
    const formValue = this.loginForm.value;
    this.firebaseService.getUser(formValue.email).subscribe(
      (res: any) => {
        if (res.size == 1) {
          try {
            const result = this.afAuth
              .signInWithEmailAndPassword(formValue.email, formValue.password);
            this.afAuth.authState.subscribe((user) => {
              if (user) {
                this.firebaseService.getAdminSingle(formValue.email).subscribe((res:any)=>{
                  this.userService.setDataInLocalStorage('user', JSON.stringify(res));
                  this.userService.setDataInLocalStorage('email', formValue.email);
                  this.router.navigate(['apprenants']);
                })
              }
            });
          } catch (error: any) {
            window.alert(error.message);
          }
        }
      }
    )
  }
  public isLogedIn() {
    if (this.userService.getUserDetails() != null) {
      this.isLogin = true
    }
  }

  ngOnInit(): void {
    this.isLogedIn()
  }

}

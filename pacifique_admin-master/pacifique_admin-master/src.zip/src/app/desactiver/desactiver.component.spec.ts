import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DesactiverComponent } from './desactiver.component';

describe('DesactiverComponent', () => {
  let component: DesactiverComponent;
  let fixture: ComponentFixture<DesactiverComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DesactiverComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DesactiverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

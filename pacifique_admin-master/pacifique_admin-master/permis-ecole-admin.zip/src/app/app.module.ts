import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFirestoreModule } from '@angular/fire/compat/firestore';
import { environment } from '../environments/environment';
import { AngularFireAuthModule } from '@angular/fire/compat/auth';
import { AngularFireStorageModule } from '@angular/fire/compat/storage';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GestionComponent } from './gestion/gestion.component';
import { ApprenantsComponent } from './apprenants/apprenants.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { ModifierComponent } from './apprenants/modifier/modifier.component';
import { AjouterComponent } from './apprenants/ajouter/ajouter.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MessagesComponent } from './messages/messages.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { FourOhFourComponent } from './four-oh-four/four-oh-four.component';
import { FormComponent } from './form/form.component';
import { HttpClientModule } from '@angular/common/http';
import { DesactiverComponent } from './desactiver/desactiver.component';


@NgModule({
  declarations: [
    AppComponent,
    GestionComponent,
    ApprenantsComponent,
    NavbarComponent,
    SidebarComponent,
    FooterComponent,
    ModifierComponent,
    AjouterComponent,
    MessagesComponent,
    SignupComponent,
    LoginComponent,
    FourOhFourComponent,
    FormComponent,
    DesactiverComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    AngularFireModule.initializeApp(environment.firebase),
 	  AngularFirestoreModule,
    AngularFireAuthModule,
    AngularFireStorageModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FirebaseService } from '../services/firebase.service';

@Component({
  selector: 'app-apprenants',
  templateUrl: './apprenants.component.html',
  styleUrls: ['./apprenants.component.scss']
})
export class ApprenantsComponent implements OnInit {
  public datas: any[] = [];
    isShow = false


  constructor(private userService: AuthService, public afAuth: AngularFireAuth,
    private router: Router, private firebaseService: FirebaseService) { }

  ngOnInit(): void {
    this.firebaseService.getApprenantsT(50).subscribe(
      (res:any) => (this.datas = res,this.isShow  = true)
    )
  }
  delete(id:string){
    this.firebaseService.validate(id)
  }
  modify(id:string){
    this.userService.setDataInLocalStorage('id',id)
    this.router.navigate([`apprenants/modifier`])
  }
  logout() {
    this.userService.clearStorage();
    return this.afAuth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['login']);
    });
  }

}

import { Injectable } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { AngularFirestore } from '@angular/fire/compat/firestore';


import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  constructor(private db: AngularFirestore, private storage: AngularFireStorage, private userservice: AuthService) { }

  pushDocToStorage(fileUpload: any, pdfUpload: any, datas: any, type: string): Observable<number | undefined> {
    const filePath = `couvertures/${type}/${fileUpload.file.name}`;
    const pdfPath = `pdf/${type}/${pdfUpload.file.name}`;
    const storageRef = this.storage.ref(filePath);
    const pdfRef = this.storage.ref(pdfPath);
    const uploadTask = this.storage.upload(filePath, fileUpload.file);
    const uploadPdfTask = this.storage.upload(pdfPath, pdfUpload.file);

    uploadTask.snapshotChanges().pipe(
      finalize(() => {
        storageRef.getDownloadURL().subscribe(downloadURL => {
          uploadPdfTask.snapshotChanges().pipe(
            finalize(() => {
              pdfRef.getDownloadURL().subscribe(downloadPdfURL => {

                var data = {
                  ...datas,
                  photo: downloadURL,
                  lien: downloadPdfURL,
                  altImg: fileUpload.file.name,
                  altPdf: pdfUpload.file.name,
                }
                this.saveFileData(data, type);
              });
            })
          ).subscribe();
        });
      })
    ).subscribe();

    return uploadTask.percentageChanges();
  }
  pushFileToStorage(fileUpload: any, datas: any, type: string): Observable<number | undefined> {
    const filePath = `couvertures/${type}/${fileUpload.file.name}`;
    const storageRef = this.storage.ref(filePath);
    const uploadTask = this.storage.upload(filePath, fileUpload.file);

    uploadTask.snapshotChanges().pipe(
      finalize(() => {
        storageRef.getDownloadURL().subscribe(downloadURL => {
          var data = {
            ...datas,
            photo: downloadURL,
            altImg: fileUpload.file.name,
          }
          this.saveFileData(data, type);
        });
      })
    ).subscribe();

    return uploadTask.percentageChanges();
  }

  updateToStorage(fileUpload: any, datas: any, type: string, id: any): Observable<number | undefined> {
    const filePath = `couvertures/${type}/${fileUpload.file.name}`;
    const storageRef = this.storage.ref(filePath);
    const uploadTask = this.storage.upload(filePath, fileUpload.file);

    uploadTask.snapshotChanges().pipe(
      finalize(() => {
        storageRef.getDownloadURL().subscribe(downloadURL => {
          var data = {
            ...datas,
            photo: downloadURL,
            altImg: fileUpload.file.name,
          }
          this.updateFileData(data, type, id);
        });
      })
    ).subscribe();

    return uploadTask.percentageChanges();
  }

  updateDocToStorage(fileUpload: any, pdfUpload: any, datas: any, type: string, id: any): Observable<number | undefined> {
    const filePath = `couvertures/${type}/${fileUpload.file.name}`;
    const pdfPath = `pdf/${type}/${pdfUpload.file.name}`;
    const storageRef = this.storage.ref(filePath); 
    const pdfRef = this.storage.ref(pdfPath);
    const uploadTask = this.storage.upload(filePath, fileUpload.file);
    const uploadPdfTask = this.storage.upload(pdfPath, pdfUpload.file);

    uploadTask.snapshotChanges().pipe(
      finalize(() => {
        storageRef.getDownloadURL().subscribe(downloadURL => {
          uploadPdfTask.snapshotChanges().pipe(
            finalize(() => {
              pdfRef.getDownloadURL().subscribe(downloadPdfURL => {
                var data = {
                  ...datas,
                  photo: downloadURL,
                  file: downloadPdfURL,
                  altImg: fileUpload.file.name,
                  altPdf: pdfUpload.file.name,

                }
                this.updateFileData(data, type, id);
              });
            })
          ).subscribe();
        });
      })
    ).subscribe();

    return uploadTask.percentageChanges();
  }

  private saveFileData(fileUpload: any, type: string): void {
    this.db.collection(type).add(fileUpload);
  }
  private updateFileData(fileUpload: any, type: string, id: any): void {
    this.db.doc(`${type}/${id}`).update(fileUpload);
  }

  deleteFile(fileUpload: any, type: string): void {
    this.deleteFileStorage(fileUpload, type);
  }
  deleteDoc(fileUpload: any,pdf:any , type: string): void {
    this.deleteDocStorage(fileUpload,pdf, type);
  }
  private deleteFileStorage(name: string, type: string): void {
    const storageRef = this.storage.ref(`couvertures/${type}`);
    storageRef.child(name).delete();
  }
  private deleteDocStorage(name: string, pdf: string, type: string): void {
    const storageRef = this.storage.ref(`couvertures/${type}`);
    const storagePdfRef = this.storage.ref(`pdf/${type}`);
    storageRef.child(name).delete();
    storagePdfRef.child(pdf).delete();
  }
}

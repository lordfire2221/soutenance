import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {

  constructor(public db: AngularFirestore) { }
  
  createUsers(value: any) {
    return this.db.collection('admin').add(value);
  }
  createApprenants(value: any) {
    return this.db.collection('apprenants').add(value);
  }
  modifyApprenant(value: any,id:any) {
    return this.db.doc(`apprenants/${id}`).update(value);
  }
  validate(id:any) {
    return this.db.doc(`apprenants/${id}`).update({statut:true});
  }
  desactivate(id:any) {
    return this.db.doc(`apprenants/${id}`).update({statut:false});
  }
  getApprenants(limit:number) {
    return this.db.collection("apprenants",ref=>ref.limit(limit).where("statut","==",false)).valueChanges({idField:'id'});
  }
  
  getApprenantsT(limit:number) {
    return this.db.collection("apprenants",ref=>ref.limit(limit)).valueChanges({idField:'id'});
  }
  getMessages(limit:number) {
    return this.db.collection("contacts",ref=>ref.limit(limit)).valueChanges({idField:'id'});
  }
  getUser(email:number) {
    return this.db.collection("admin",ref=>ref.where("email","==",email)).valueChanges({idField:'id'});
  }
  getApprenant(id:string) {
    return this.db.doc(`apprenants/${id}`).valueChanges();
  }
  getApprenantsEnCours() {
    return this.db.collection("apprenants",ref=>ref.where("statut","==",true)).valueChanges({idField:'id'});
  }
  delete(id: any) {
    return this.db.collection("apprenants").doc(id).delete();
  }
  deleteMessage(id: any) {
    return this.db.collection("contacts").doc(id).delete();
  }
}

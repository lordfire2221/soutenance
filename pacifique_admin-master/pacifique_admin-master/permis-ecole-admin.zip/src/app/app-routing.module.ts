import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AjouterComponent } from './apprenants/ajouter/ajouter.component';
import { ApprenantsComponent } from './apprenants/apprenants.component';
import { ModifierComponent } from './apprenants/modifier/modifier.component';
import { DesactiverComponent } from './desactiver/desactiver.component';
import { FourOhFourComponent } from './four-oh-four/four-oh-four.component';
import { GestionComponent } from './gestion/gestion.component';
import { Authguard } from './guard/auth.guard';
import { LoginComponent } from './login/login.component';
import { MessagesComponent } from './messages/messages.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {
    path:'not-found',component:FourOhFourComponent
  },
  {
    path:'login',component:LoginComponent
  },
  {
    path:'signup',component:SignupComponent
  },
  {
    path:'',redirectTo:'/apprenants',pathMatch:'full'
  },
  {
    path:'gestion',canActivate:[Authguard],component:GestionComponent
  },
  {
    path:'desactiver',canActivate:[Authguard],component:DesactiverComponent
  },
  {
    path:'messages',canActivate:[Authguard],component:MessagesComponent
  },
  {
    path:'apprenants',canActivate:[Authguard],component:ApprenantsComponent
  },
  {
    path:'apprenants/modifier',canActivate:[Authguard],component:ModifierComponent
  },
  {
    path:'apprenants/ajouter',canActivate:[Authguard],component:AjouterComponent
  },
  {
    path:'**',redirectTo:'/not-found',pathMatch:'full'
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

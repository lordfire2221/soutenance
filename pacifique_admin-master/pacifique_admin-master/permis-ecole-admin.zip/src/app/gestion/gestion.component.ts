import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FirebaseService } from '../services/firebase.service';
import { ApiService } from '../services/api.service';
import { MessageClient } from 'cloudmailin';

@Component({
  selector: 'app-gestion',
  templateUrl: './gestion.component.html',
  styleUrls: ['./gestion.component.scss']
})
export class GestionComponent implements OnInit {
  public datas: any[] = [];
  isShow = false
  constructor(private userService: AuthService, public afAuth: AngularFireAuth,
    private router: Router, private firebaseService: FirebaseService, private apiService: ApiService) { }

  ngOnInit(): void {
    this.firebaseService.getApprenants(30).subscribe(
      (res: any) => (this.datas = res, this.isShow = true, console.log(res))
    )
  }
  activate(id: string) {
    this.firebaseService.validate(id);
    this.firebaseService.getApprenant(id).subscribe(
      async (res: any) => {
        // const client = new MessageClient({ username: '293731b2f948c506', apiKey: 'fLyqGJTny7bBrCv7BS7EXBKf' });
        // const response = await client.sendMessage({
        //   to: 'test@example.net',
        //   from: 'test@example.com',
        //   plain: 'test message',
        //   html: '<h1>Vos </h1>',
        //   subject: "hello world"
        // });
      }
    );
  }
  desactivate(id: string) {
    this.firebaseService.validate(id)
  }
  logout() {
    this.userService.clearStorage();
    return this.afAuth.signOut().then(() => {
      localStorage.removeItem('token');
      this.router.navigate(['login']);
    });
  }

}
